﻿using System.Windows.Forms;

namespace Lets__study_.Styles.ButtonsS.Interface
{
    public interface IButtonStyle
    {

        void GetStyle(Button button);

    }
}
