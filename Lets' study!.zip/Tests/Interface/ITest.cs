﻿using System.Collections.Generic;

namespace Lets__study_.Tests.Interface
{
    interface ITest
    {
        Dictionary<string, string> QuestionDictionary { get; set; }
    }
}
