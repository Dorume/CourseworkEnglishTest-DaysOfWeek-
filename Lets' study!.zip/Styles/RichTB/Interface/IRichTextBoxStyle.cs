﻿using System.Windows.Forms;
namespace Lets__study_.Styles.RichTB.Interface
{
    public interface IRichTextBoxStyle
    {
        void GetStyle(RichTextBox textBox);
    }
}
