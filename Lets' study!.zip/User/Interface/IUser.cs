﻿namespace Lets__study_.User.Interface
{
    public interface IUser
    {
        string Name { get; set; }
        string Surname { get; set; }
    }
}
