﻿using System.Windows.Forms;

namespace Lets__study_.Styles.Panels.Interface
{
    public interface IPanelStyle
    {
        void GetStyle(Panel panel);
    }
}
