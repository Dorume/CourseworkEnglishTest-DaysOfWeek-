﻿using Lets__study_.User.Interface;

namespace Lets__study_.User
{
    class User : IUser
    {
        public string Name { get; set; }
        public string Surname { get; set; }
    }
}
